<?php 
 
 $con = mysqli_connect("localhost","root","","gm") or die("Mantenimiento...");

?>